import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'screens/shell.dart';
import 'theme/app_theme.dart';
import 'theme/theme_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final themeController = ThemeController();
  await themeController.load();
  runApp(
    ChangeNotifierProvider<ThemeController>.value(
      value: themeController,
      child: const AssetoApp(),
    ),
  );
}

class AssetoApp extends StatelessWidget {
  const AssetoApp({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ThemeController>();
    return MaterialApp(
      title: 'ASSETO',
      debugShowCheckedModeBanner: false,
      themeMode: c.mode,
      theme: buildTheme(c.lightPalette, Brightness.light),
      darkTheme: buildTheme(c.darkPalette, Brightness.dark),
      home: const Shell(),
    );
  }
}
