import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_palette.dart';

/// Holds theme mode and colors.
/// Layers: built-in defaults -> admin panel override (step 4) -> user accent.
class ThemeController extends ChangeNotifier {
  ThemeMode _mode = ThemeMode.dark;
  Color? _userPrimary;
  AppPalette _baseDark = AppPalette.defaultDark;
  AppPalette _baseLight = AppPalette.defaultLight;
  SharedPreferences? _prefs;

  ThemeMode get mode => _mode;
  Color? get userPrimary => _userPrimary;
  AppPalette get darkPalette => _withUser(_baseDark);
  AppPalette get lightPalette => _withUser(_baseLight);

  AppPalette _withUser(AppPalette p) =>
      _userPrimary == null ? p : p.copyWith(primary: _userPrimary);

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _prefs = prefs;

      final m = prefs.getString('theme_mode');
      if (m == 'light') {
        _mode = ThemeMode.light;
      } else if (m == 'system') {
        _mode = ThemeMode.system;
      } else {
        _mode = ThemeMode.dark;
      }

      final up = prefs.getInt('user_primary');
      if (up != null) _userPrimary = Color(up);

      _baseDark = _readCached(prefs, 'remote_palette_dark', AppPalette.defaultDark);
      _baseLight = _readCached(prefs, 'remote_palette_light', AppPalette.defaultLight);
    } catch (_) {
      // If storage fails, the app still starts with defaults.
    }
  }

  AppPalette _readCached(SharedPreferences prefs, String key, AppPalette base) {
    final raw = prefs.getString(key);
    if (raw == null) return base;
    try {
      final map = jsonDecode(raw);
      if (map is Map<String, dynamic>) return AppPalette.fromJson(map, base);
    } catch (_) {}
    return base;
  }

  Future<void> setMode(ThemeMode mode) async {
    _mode = mode;
    notifyListeners();
    final value = mode == ThemeMode.light
        ? 'light'
        : mode == ThemeMode.system
            ? 'system'
            : 'dark';
    await _prefs?.setString('theme_mode', value);
  }

  Future<void> setUserPrimary(Color color) async {
    _userPrimary = color;
    notifyListeners();
    await _prefs?.setInt('user_primary', color.toARGB32());
  }

  /// Removes the user's accent color. Admin colors (if any) stay.
  Future<void> resetColors() async {
    _userPrimary = null;
    notifyListeners();
    await _prefs?.remove('user_primary');
  }

  /// Called by the Firebase config loader in step 4.
  Future<void> applyRemote({
    Map<String, dynamic>? dark,
    Map<String, dynamic>? light,
  }) async {
    if (dark != null) {
      _baseDark = AppPalette.fromJson(dark, AppPalette.defaultDark);
      await _prefs?.setString('remote_palette_dark', jsonEncode(_baseDark.toJson()));
    }
    if (light != null) {
      _baseLight = AppPalette.fromJson(light, AppPalette.defaultLight);
      await _prefs?.setString('remote_palette_light', jsonEncode(_baseLight.toJson()));
    }
    notifyListeners();
  }

  /// Admin "Reset to default".
  Future<void> clearRemote() async {
    _baseDark = AppPalette.defaultDark;
    _baseLight = AppPalette.defaultLight;
    await _prefs?.remove('remote_palette_dark');
    await _prefs?.remove('remote_palette_light');
    notifyListeners();
  }
}
