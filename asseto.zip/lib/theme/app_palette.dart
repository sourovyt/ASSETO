import 'package:flutter/material.dart';

/// All colors used in the app live here, so they can be changed from one place
/// (defaults -> admin panel override -> user override).
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.primary,
    required this.background,
    required this.card,
    required this.text,
    required this.mutedText,
    required this.income,
    required this.spending,
    required this.warning,
    required this.info,
  });

  final Color primary;
  final Color background;
  final Color card;
  final Color text;
  final Color mutedText;
  final Color income;
  final Color spending;
  final Color warning;
  final Color info;

  /// Dark + purple, like the reference app.
  static const defaultDark = AppPalette(
    primary: Color(0xFF9B5DE5),
    background: Color(0xFF18191B),
    card: Color(0xFF26272A),
    text: Color(0xFFEDEDED),
    mutedText: Color(0xFF9A9CA1),
    income: Color(0xFF4CAF7A),
    spending: Color(0xFFF26B3A),
    warning: Color(0xFFF5A623),
    info: Color(0xFF3B82F6),
  );

  static const defaultLight = AppPalette(
    primary: Color(0xFF8A4BD8),
    background: Color(0xFFF5F4F8),
    card: Color(0xFFFFFFFF),
    text: Color(0xFF1B1B1F),
    mutedText: Color(0xFF6B6D73),
    income: Color(0xFF2E9E6A),
    spending: Color(0xFFE0541F),
    warning: Color(0xFFD98A00),
    info: Color(0xFF2563EB),
  );

  @override
  AppPalette copyWith({
    Color? primary,
    Color? background,
    Color? card,
    Color? text,
    Color? mutedText,
    Color? income,
    Color? spending,
    Color? warning,
    Color? info,
  }) {
    return AppPalette(
      primary: primary ?? this.primary,
      background: background ?? this.background,
      card: card ?? this.card,
      text: text ?? this.text,
      mutedText: mutedText ?? this.mutedText,
      income: income ?? this.income,
      spending: spending ?? this.spending,
      warning: warning ?? this.warning,
      info: info ?? this.info,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      primary: Color.lerp(primary, other.primary, t)!,
      background: Color.lerp(background, other.background, t)!,
      card: Color.lerp(card, other.card, t)!,
      text: Color.lerp(text, other.text, t)!,
      mutedText: Color.lerp(mutedText, other.mutedText, t)!,
      income: Color.lerp(income, other.income, t)!,
      spending: Color.lerp(spending, other.spending, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      info: Color.lerp(info, other.info, t)!,
    );
  }

  Map<String, int> toJson() => {
        'primary': primary.toARGB32(),
        'background': background.toARGB32(),
        'card': card.toARGB32(),
        'text': text.toARGB32(),
        'mutedText': mutedText.toARGB32(),
        'income': income.toARGB32(),
        'spending': spending.toARGB32(),
        'warning': warning.toARGB32(),
        'info': info.toARGB32(),
      };

  /// Reads colors from a map (ARGB ints). Missing keys fall back to [base].
  static AppPalette fromJson(Map<String, dynamic> m, AppPalette base) {
    Color pick(String key, Color fallback) {
      final v = m[key];
      return v is int ? Color(v) : fallback;
    }

    return AppPalette(
      primary: pick('primary', base.primary),
      background: pick('background', base.background),
      card: pick('card', base.card),
      text: pick('text', base.text),
      mutedText: pick('mutedText', base.mutedText),
      income: pick('income', base.income),
      spending: pick('spending', base.spending),
      warning: pick('warning', base.warning),
      info: pick('info', base.info),
    );
  }
}
