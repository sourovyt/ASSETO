import 'package:flutter/material.dart';

import 'app_palette.dart';

ThemeData buildTheme(AppPalette p, Brightness brightness) {
  final base = ThemeData(useMaterial3: true, brightness: brightness);
  final scheme = ColorScheme.fromSeed(
    seedColor: p.primary,
    brightness: brightness,
  ).copyWith(
    primary: p.primary,
    onPrimary: Colors.white,
    surface: p.card,
    onSurface: p.text,
  );

  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: p.background,
    cardColor: p.card,
    dividerColor: p.mutedText.withValues(alpha: 0.2),
    textTheme: base.textTheme.apply(bodyColor: p.text, displayColor: p.text),
    appBarTheme: AppBarTheme(
      backgroundColor: p.background,
      foregroundColor: p.text,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
    extensions: <ThemeExtension<dynamic>>[p],
  );
}
