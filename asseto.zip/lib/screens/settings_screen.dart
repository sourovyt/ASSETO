import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_palette.dart';
import '../theme/theme_controller.dart';

const _accents = <Color>[
  Color(0xFF9B5DE5), // purple (default)
  Color(0xFFF2551C), // orange (logo)
  Color(0xFF3B82F6), // blue
  Color(0xFF2EB67D), // green
  Color(0xFFE5589D), // pink
  Color(0xFF14B8A6), // teal
];

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = context.watch<ThemeController>();
    final p = Theme.of(context).extension<AppPalette>()!;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Appearance',
              style: TextStyle(
                  color: p.primary, fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: p.card,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Theme',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<ThemeMode>(
                    segments: const [
                      ButtonSegment(
                          value: ThemeMode.light, label: Text('Light')),
                      ButtonSegment(value: ThemeMode.dark, label: Text('Dark')),
                      ButtonSegment(
                          value: ThemeMode.system, label: Text('Auto')),
                    ],
                    selected: {c.mode},
                    onSelectionChanged: (s) => c.setMode(s.first),
                  ),
                ),
                const SizedBox(height: 20),
                const Text('Accent color',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    for (var i = 0; i < _accents.length; i++)
                      _Swatch(
                        color: _accents[i],
                        selected: c.userPrimary == null
                            ? i == 0
                            : c.userPrimary!.toARGB32() ==
                                _accents[i].toARGB32(),
                        onTap: () => c.setUserPrimary(_accents[i]),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: c.resetColors,
                    child: const Text('Reset colors'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Swatch extends StatelessWidget {
  const _Swatch({
    required this.color,
    required this.selected,
    required this.onTap,
  });

  final Color color;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: 'Accent color',
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(
              color: selected ? Colors.white : Colors.transparent,
              width: 3,
            ),
          ),
          child: selected
              ? const Icon(Icons.check_rounded, color: Colors.white)
              : null,
        ),
      ),
    );
  }
}
