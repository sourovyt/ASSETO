import 'package:flutter/material.dart';

import '../theme/app_palette.dart';
import 'home_screen.dart';
import 'placeholder_screen.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _index = 0;

  static const _items = <_NavSpec>[
    _NavSpec('Home', Icons.home_rounded),
    _NavSpec('Holdings', Icons.account_balance_wallet_rounded),
    _NavSpec('Earnings', Icons.trending_up_rounded),
    _NavSpec('Trades', Icons.candlestick_chart_rounded),
    _NavSpec('More', Icons.grid_view_rounded),
  ];

  static const _pages = <Widget>[
    HomeScreen(),
    PlaceholderScreen(
      title: 'Holdings',
      icon: Icons.account_balance_wallet_rounded,
      note: 'Tokens and USDT, exchange by exchange.',
    ),
    PlaceholderScreen(
      title: 'Earnings',
      icon: Icons.trending_up_rounded,
      note: 'Where your web3 income comes from.',
    ),
    PlaceholderScreen(
      title: 'Trades',
      icon: Icons.candlestick_chart_rounded,
      note: 'Buys, sells, profit and loss.',
    ),
    PlaceholderScreen(
      title: 'More',
      icon: Icons.grid_view_rounded,
      note: 'Airdrop tracker, transfer log and settings.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final p = Theme.of(context).extension<AppPalette>()!;
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: p.mutedText.withValues(alpha: 0.15)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              for (var i = 0; i < _items.length; i++)
                _NavButton(
                  spec: _items[i],
                  selected: i == _index,
                  palette: p,
                  onTap: () => setState(() => _index = i),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavSpec {
  const _NavSpec(this.label, this.icon);
  final String label;
  final IconData icon;
}

class _NavButton extends StatelessWidget {
  const _NavButton({
    required this.spec,
    required this.selected,
    required this.palette,
    required this.onTap,
  });

  final _NavSpec spec;
  final bool selected;
  final AppPalette palette;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: spec.label,
      button: true,
      selected: selected,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          decoration: BoxDecoration(
            color: selected
                ? palette.primary.withValues(alpha: 0.18)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(
            spec.icon,
            size: 26,
            color: selected ? palette.primary : palette.mutedText,
          ),
        ),
      ),
    );
  }
}
