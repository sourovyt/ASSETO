import 'package:flutter/material.dart';

import '../theme/app_palette.dart';

class PlaceholderScreen extends StatelessWidget {
  const PlaceholderScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.note,
  });

  final String title;
  final IconData icon;
  final String note;

  @override
  Widget build(BuildContext context) {
    final p = Theme.of(context).extension<AppPalette>()!;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: p.card,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Icon(icon, size: 40, color: p.mutedText),
                    ),
                    const SizedBox(height: 18),
                    Text(note,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16, color: p.text)),
                    const SizedBox(height: 4),
                    Text('This screen is built in the next step.',
                        style: TextStyle(fontSize: 14, color: p.mutedText)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
